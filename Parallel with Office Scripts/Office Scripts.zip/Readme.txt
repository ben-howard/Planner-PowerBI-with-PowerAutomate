[221811] - Updated the scripts with the following code - delete_tbl.getRangeBetweenHeaderAndTotal().delete(0) - thanks to Charles Ulrich for the update :) 

Copy these scripts into the Code Editor in Excel online.  You can call the scripts what you want, but my recommendation is to maintain the current naming structure.